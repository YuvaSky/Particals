package com.flight;



import java.util.List;

import com.doa.InstructorDao;
import com.entity.Instructor;
import com.entity.InstructorDetail;

public class App 
{
    public static void main( String[] args )
    {
        // Save two instructor
        Instructor instructor = new Instructor(1, "Airindia", "paasenger",50 );
        InstructorDetail InstructorDetail = new InstructorDetail( );
        InstructorDetail.setInstructor(instructor);
		instructor.setInstructorDetail(InstructorDetail);
       
        Instructor instructor1 = new Instructor(2, "Jagaur", "Fighter", 5 );
        InstructorDetail instructorDetail1 = new InstructorDetail();
		instructorDetail1.setInstructor(instructor1);
        instructor1.setInstructorDetail(instructorDetail1);
       
        InstructorDao instructorDao = new InstructorDao();
        instructorDao.saveInstructor(instructor);
        instructorDao.saveInstructor(instructor1);
       
        // Get all instructors
        List<Instructor> instructors = instructorDao.getAllInstructor();
        instructors.forEach(instructorTemp -> System.out.println(instructorTemp.getFlight_name()));
    }
}
