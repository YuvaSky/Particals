package com.entity;

import jakarta.persistence.*;


@Entity
@Table(name="flight")
public class Instructor {
	
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id")
	private int flight_id;
	
	@Column(name="flight_name")
	private String flight_name;
	
	@Column(name="carrier_name")
	private String carrier_name;
	
	@Column(name="total_capicity")
	private int total_capacity;
	
	@OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="instructor_detail_id")
    private InstructorDetail instructorDetail;
	
	// deafault constructor
    public Instructor() {
        
    }
     //parameterized constructor
	public Instructor(int flight_id, String flight_name, String carrier_name, int total_capacity) {
		this.flight_id = flight_id;
		this.flight_name = flight_name;
		this.carrier_name = carrier_name;
		this.total_capacity = total_capacity;
	}
	
	//gatter & Setter
	public int getFlight_id() {
		return flight_id;
	}
	public void setFlight_id(int flight_id) {
		this.flight_id = flight_id;
	}
	public String getFlight_name() {
		return flight_name;
	}
	public void setFlight_name(String flight_name) {
		this.flight_name = flight_name;
	}
	public String getCarrier_name() {
		return carrier_name;
	}
	public void setCarrier_name(String carrier_name) {
		this.carrier_name = carrier_name;
	}
	public int getTotal_capacity() {
		return total_capacity;
	}
	public void setTotal_capacity(int total_capacity) {
		this.total_capacity = total_capacity;
	}
	
	public InstructorDetail getInstructorDetail() {
        return instructorDetail;
    }
	
	public void setInstructorDetail(InstructorDetail instructorDetail) {
        this.instructorDetail = instructorDetail;
    }
	@Override
	public String toString() {
		return "instructor [flight_id=" + flight_id + ", flight_name=" + flight_name + ", carrier_name=" + carrier_name
				+ ", total_capacity=" + total_capacity + ",instructorDetail=" + instructorDetail + "]";
	}

	
		
	}

	


	
		
	
	


 

