package com.entity;

import jakarta.persistence.*;

@Entity
@Table(name="flight_detail")
public class InstructorDetail {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
    //variables
    @Column(name="id")
	private int id;
	
	@Column(name="Name")
	private String Name;
	
	@Column(name="carriername")
	private String carriername;
	
	@Column(name="totalcapicity")
	private int totalcapicity;
	
    @OneToOne(mappedBy="instructorDetail", cascade=CascadeType.ALL)
	private Instructor instructor;
	
    //default constructor
	public InstructorDetail(){
		
	}
	 public InstructorDetail(String Name, String carrier) {
	        this.Name = Name;
	        this.carriername = carriername;
	
	 }
	 
	  //getter & setter
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getCarriername() {
		return carriername;
	}
	public void setCarriername(String carriername) {
		this.carriername = carriername;
	}
	public int getTotalcapicity() {
		return totalcapicity;
	}
	public void setTotalcapicity(int totalcapicity) {
		this.totalcapicity = totalcapicity;
	}
	public Instructor getInstructor() {
		return instructor;
	}
	public  void setInstructor(Instructor instructor) {
		this.instructor = instructor;
	}
	@Override
	public String toString() {
		return "instructorDetail [id=" + id + ", Name=" + Name + ", carriername=" + carriername + ", totalcapicity="
				+ totalcapicity + "]";
	}
	 
	 
	 }
	
	


